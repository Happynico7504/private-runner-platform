from Crypto.Signature import pss
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA
from Crypto import Random

message = '01 14:4 1PASH9A0910161:unlock_serial_len'
key = RSA.import_key(open('oculus.privkey.der').read())
h = SHA256.new(message)
signature = pss.new(key).sign(h)